class UrnaEletronica:
    
    def __init__(self, votosPresidente, votosSenador) :
        self.votosPresidente = votosPresidente
        self.votosSenador = votosSenador