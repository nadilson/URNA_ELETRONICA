# Urna eletrônica em python

Projeto da disciplina 
Ministrada pelo professor:

Alunos:

Ednilson Messias Castro dos Santos
Renata Gomes
Georgen
Marco Antônio
Nadilson Lima

Para inicar o programa digite o seguinte comando no terminal:
``
python main.py
``